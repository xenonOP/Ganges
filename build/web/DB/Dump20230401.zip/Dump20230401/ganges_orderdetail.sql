-- MySQL dump 10.13  Distrib 8.0.32, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: ganges
-- ------------------------------------------------------
-- Server version	8.0.32

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `orderdetail`
--

DROP TABLE IF EXISTS `orderdetail`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `orderdetail` (
  `idorderdetail` int NOT NULL AUTO_INCREMENT,
  `orderid` int DEFAULT NULL,
  `productid` int DEFAULT NULL,
  `offp` varchar(450) DEFAULT NULL,
  `price` varchar(450) DEFAULT NULL,
  `quant` int DEFAULT NULL,
  `prdname` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`idorderdetail`),
  KEY `orderid_idx` (`orderid`),
  KEY `productid_idx` (`productid`),
  CONSTRAINT `orderid` FOREIGN KEY (`orderid`) REFERENCES `ordertable` (`orderid`),
  CONSTRAINT `prdid1` FOREIGN KEY (`productid`) REFERENCES `product` (`productid`)
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `orderdetail`
--

LOCK TABLES `orderdetail` WRITE;
/*!40000 ALTER TABLE `orderdetail` DISABLE KEYS */;
INSERT INTO `orderdetail` VALUES (1,14,51,'959','2399',3,'Reebok Womens All Day Cropped Crew Neck Sweater'),(2,15,68,'595','1599',2,'Infant%20Newborn%20Baby%20Girl%20Summer%20Clothes'),(3,16,17,'34400','36253',1,'ASUS Laptop L510, 15.6\" Full HD, Intel Pentium Silver N5030'),(4,16,72,'649','2999',2,'GRECIILOOKS%20Western%20Top%20for%20Women%20Floral%20Printed%20'),(5,17,77,'343','459',1,'Denorex%20Extra%20Strength%20Medicated%20Dandruff%20Relief'),(6,17,53,'1899','2299',1,'Scoop Womens Small Straw Crescent Crossbody Bag, Natural'),(7,19,51,'959','2399',1,'Reebok Womens All Day Cropped Crew Neck Sweater'),(8,19,17,'34400','36253',1,'ASUS Laptop L510, 15.6\" Full HD, Intel Pentium Silver N5030'),(9,20,51,'959','2399',1,'Reebok Womens All Day Cropped Crew Neck Sweater'),(10,20,68,'595','1599',1,'Infant%20Newborn%20Baby%20Girl%20Summer%20Clothes'),(11,21,52,'508','899',1,'Varsbaby Sexy lace Bra Half Cup Push Up UnderwearThin Cotton'),(12,21,17,'34400','36253',1,'ASUS Laptop L510, 15.6\" Full HD, Intel Pentium Silver N5030'),(13,22,17,'34400','36253',1,'ASUS Laptop L510, 15.6\" Full HD, Intel Pentium Silver N5030'),(14,22,57,'21199','54899',1,'Ainsley Velvet Adjustable Swivel Office chair'),(15,23,79,'1650','1899',3,'Versed%20Skin%20Soak%20Rich%20Moisture%20Cream%2C%20Squalane%2C%20%20Red%20Algae'),(16,23,72,'649','2999',2,'GRECIILOOKS%20Western%20Top%20for%20Women%20Floral%20Printed%20'),(17,24,77,'343','459',2,'Denorex%20Extra%20Strength%20Medicated%20Dandruff%20Relief'),(18,24,52,'508','899',1,'Varsbaby Sexy lace Bra Half Cup Push Up UnderwearThin Cotton'),(19,25,59,'6499','10219',1,'Better Homes and Gardens Light Grey upholstered'),(20,25,77,'343','459',1,'Denorex%20Extra%20Strength%20Medicated%20Dandruff%20Relief'),(21,25,75,'3000','3780',1,'Olaplex%20No.%206%20Bond%20Smoother%20Leave-In%20Reparative'),(22,26,56,'19999','14999',1,'Costway Sideboard Buffet Table Wooden Console Table'),(23,26,17,'34400','36253',1,'ASUS Laptop L510, 15.6\" Full HD, Intel Pentium Silver N5030'),(24,27,68,'595','1599',2,'Infant%20Newborn%20Baby%20Girl%20Summer%20Clothes'),(25,27,51,'959','2399',1,'Reebok Womens All Day Cropped Crew Neck Sweater'),(26,27,59,'6499','10219',2,'Better Homes and Gardens Light Grey upholstered'),(27,29,51,'959','2399',1,'Reebok Womens All Day Cropped Crew Neck Sweater'),(28,29,68,'595','1599',1,'Infant%20Newborn%20Baby%20Girl%20Summer%20Clothes'),(29,30,17,'34400','36253',4,'ASUS Laptop L510, 15.6\" Full HD, Intel Pentium Silver N5030'),(30,30,57,'21199','54899',1,'Ainsley Velvet Adjustable Swivel Office chair'),(31,31,52,'508','899',1,'Varsbaby Sexy lace Bra Half Cup Push Up UnderwearThin Cotton');
/*!40000 ALTER TABLE `orderdetail` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-04-01 17:08:28
