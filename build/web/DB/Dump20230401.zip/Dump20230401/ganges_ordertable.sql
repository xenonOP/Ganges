-- MySQL dump 10.13  Distrib 8.0.32, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: ganges
-- ------------------------------------------------------
-- Server version	8.0.32

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `ordertable`
--

DROP TABLE IF EXISTS `ordertable`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ordertable` (
  `orderid` int NOT NULL AUTO_INCREMENT,
  `username` varchar(450) DEFAULT NULL,
  `deladdress` varchar(500) DEFAULT NULL,
  `city` varchar(45) DEFAULT NULL,
  `phone` varchar(45) DEFAULT NULL,
  `email` varchar(45) DEFAULT NULL,
  `zip` varchar(45) DEFAULT NULL,
  `country` varchar(45) DEFAULT NULL,
  `FirstN` varchar(45) DEFAULT NULL,
  `LastN` varchar(45) DEFAULT NULL,
  `date` timestamp NULL DEFAULT NULL,
  `payment` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`orderid`),
  KEY `username_idx` (`username`),
  CONSTRAINT `usernaam` FOREIGN KEY (`username`) REFERENCES `new_user` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ordertable`
--

LOCK TABLES `ordertable` WRITE;
/*!40000 ALTER TABLE `ordertable` DISABLE KEYS */;
INSERT INTO `ordertable` VALUES (10,'abc','batala road, Amritsar','Amritsar','06284593018','kanishrajput123@gmail.com','143001','Ukraine','Kanish','Rajput',NULL,NULL),(11,'abc','batala road, Amritsar','Amritsar','06284593018','kanishrajput123@gmail.com','143001','Turkey','Kanish','Rajput',NULL,NULL),(12,'abc','batala road, Amritsar','Amritsar','06284593018','kanishrajput123@gmail.com','143001','United Kingdom','Kanish','Rajput',NULL,'COD'),(13,'abc','batala road, Amritsar','Amritsar','06284593018','kanishrajput123@gmail.com','143001','United Kingdom','Kanish','Rajput',NULL,'ONLINE'),(14,'abc','batala road, Amritsar','Amritsar','06284593018','kanishrajput123@gmail.com','143001','India','Kanish','Rajput',NULL,'COD'),(15,'abc','batala road, Amritsar','Amritsar','9874651230','kanishrajput123@gmail.com','143001','India','Himanshu','Rajput',NULL,'COD'),(16,'kanish','batala road, Amritsar','Amritsar','06284593018','kanishrajput123@gmail.com','143001','United Kingdom','Kanish','Rajput',NULL,'COD'),(17,'kanish','batala road, Amritsar','Amritsar','06284593018','kanishrajput123@gmail.com','143001','Turkey','Kanish','Rajput',NULL,'COD'),(18,'kanish','batala road, Amritsar','Amritsar','06284593018','kanishrajput123@gmail.com','143001','Turkey','Kanish','Rajput',NULL,'COD'),(19,'kanish','batala road, Amritsar','Amritsar','6284593018','kanishrajput123@gmail.com','143001','India','Kanish','Rajput',NULL,'COD'),(20,'kanish','batala road, Amritsar','Amritsar','06284593018','kanishrajput123@gmail.com','143001','Ukraine','Kanish','Rajput',NULL,'COD'),(21,'kanish','batala road, Amritsar','Amritsar','06284593018','kanishrajput123@gmail.com','143001','Turkey','Kanish','Rajput',NULL,'COD'),(22,'kanish','batala road, Amritsar','Amritsar','06284593018','kanishrajput123@gmail.com','143001','India','Kanish','Rajput',NULL,'COD'),(23,'kanish','batala road, Amritsar','Amritsar','6284593018','kanishrajput123@gmail.com','143001','Select','Kanish','Rajput',NULL,'COD'),(24,'kanish','964, st1, Guru Nanak nagar, Batala road, Amritsar','Amritsar','06284593018','kanishrajput123@gmail.com','143001','Uruguay','Kanish','Kumar',NULL,'COD'),(25,'kanish','batala road, Amritsar','Amritsar','6284593018','kanishrajput123@gmail.com','143001','Ukraine','Kanish','Rajput',NULL,'COD'),(26,'kanish','batala road, Amritsar','Amritsar','06284593018','kanishrajput123@gmail.com','143001','Turkey','Kanish','Rajput',NULL,'COD'),(27,'kanish','batala road, Amritsar','Amritsar','06284593018','kanishrajput123@gmail.com','143001','Turkey','Kanish','Rajput',NULL,'COD'),(28,'kanish','batala road, Amritsar','Amritsar','06284593018','kanishrajput123@gmail.com','143001','Turkey','Kanish','Rajput',NULL,'ONLINE'),(29,'kanish','batala road, Amritsar','Amritsar','06284593018','kanishrajput123@gmail.com','143001','United Kingdom','Kanish','Rajput',NULL,'ONLINE'),(30,'kanish','batala road, Amritsar','Amritsar','06284593018','kanishrajput123@gmail.com','143001','United Kingdom','Kanish','Rajput',NULL,'ONLINE'),(31,'kanish','964, st1, Guru Nanak nagar, Batala road, Amritsar','Amritsar','6565656565','kanishrajput123@gmail.com','143001','Uruguay','Kanish','Kumar',NULL,'ONLINE');
/*!40000 ALTER TABLE `ordertable` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-04-01 17:08:27
